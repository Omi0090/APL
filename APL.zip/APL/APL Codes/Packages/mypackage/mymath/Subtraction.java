package mypackage.mymath;

public class Subtraction {
    public int sub(int a, int b) {
        return a - b;
    }
}
