package mypackage.mymath;

public class Multiplication {
    public int multiply(int a, int b) {
        return a * b;
    }
}
